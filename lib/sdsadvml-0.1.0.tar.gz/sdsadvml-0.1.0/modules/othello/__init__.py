from .othello import *
