# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'modules'}

packages = \
['othello']

package_data = \
{'': ['*']}

install_requires = \
['advml @ '
 'file:///Users/tatsuya/Documents/Programs/Python/1284-sds-ml-advanced/lib/advml',
 'bokeh>=3.2.2,<4.0.0',
 'colorama>=0.4.6,<0.5.0',
 'cython>=3.0.5,<4.0.0',
 'ffmpeg>=1.4,<2.0',
 'gymnasium[classic-control]>=0.29.1,<0.30.0',
 'ipywidgets>=8.1.0,<9.0.0',
 'japanize-matplotlib>=1.1.3,<2.0.0',
 'jupyter-bokeh>=3.0.7,<4.0.0',
 'jupyterlab-widgets>=3.0.8,<4.0.0',
 'jupyterlab>=4.0.0,<5.0.0',
 'matplotlib>=3.7.1,<4.0.0',
 'networkx>=3.1,<4.0',
 'nodejs>=0.1.1,<0.2.0',
 'numpy>=1.25.0,<2.0.0',
 'opencv-contrib-python>=4.8.0.76,<5.0.0.0',
 'opencv-python>=4.8.0.74,<5.0.0.0',
 'openpyxl>=3.1.2,<4.0.0',
 'pandas>=2.0.3,<3.0.0',
 'pytest>=7.4.0,<8.0.0',
 'scikit-image>=0.21.0,<0.22.0',
 'scikit-learn>=1.2.2,<2.0.0',
 'scipy>=1.11.1,<2.0.0',
 'seaborn>=0.12.2,<0.13.0',
 'torchviz>=0.0.2,<0.0.3',
 'tqdm>=4.66.1,<5.0.0']

extras_require = \
{':sys_platform == "darwin" and (platform_machine == "arm64" or platform_machine == "aarch64")': ['torch '
                                                                                                  '@ '
                                                                                                  'https://download.pytorch.org/whl/cpu/torch-2.0.0-cp39-none-macosx_11_0_arm64.whl',
                                                                                                  'torchvision '
                                                                                                  '@ '
                                                                                                  'https://download.pytorch.org/whl/cpu/torchvision-0.15.0-cp39-cp39-macosx_11_0_arm64.whl'],
 ':sys_platform == "darwin" and platform_machine == "x86_64"': ['torch @ '
                                                                'https://download.pytorch.org/whl/cpu/torch-2.0.0-cp39-none-macosx_10_9_x86_64.whl',
                                                                'torchvision @ '
                                                                'https://download.pytorch.org/whl/cpu/torchvision-0.15.0-cp39-cp39-macosx_10_9_x86_64.whl'],
 ':sys_platform == "linux"': ['torch==2.0.0+cpu', 'torchvision==0.15.0+cpu'],
 ':sys_platform == "win32"': ['torch==2.0.0+cpu', 'torchvision==0.15.0+cpu']}

setup_kwargs = {
    'name': 'sdsadvml',
    'version': '0.1.0',
    'description': '',
    'long_description': '機械学習発展 (実践)\n===\n\n[![Github Pages](https://github.com/tatsy/1284-sds-ml-advanced/actions/workflows/gh-pages.yaml/badge.svg)](https://github.com/tatsy/1284-sds-ml-advanced/actions/workflows/gh-pages.yaml)\n[![Miniconda](https://github.com/tatsy/1284-sds-ml-advanced/actions/workflows/conda.yaml/badge.svg?branch=master)](https://github.com/tatsy/1284-sds-ml-advanced/actions/workflows/conda.yaml)\n\n[![Creative Commons License](https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png)](http://creativecommons.org/licenses/by-nc-sa/4.0/)\n\n## 講義の概要\n\nこの講義ではPythonを用いて、画像認識と機械学習の実践的な利用法について学ぶ。資料の中では、ライブラリを使った実装を用いる場合も、その背景にある理論とライブラリに頼らない簡易実装を与える。これにより、**ライブラリのユーザから卒業**し、自分の必要とする機械学習のメソッドを実装する力を養う。\n\n### 求める前提知識\n- Pythonの**読み書きが不自由なく**できる (基本的な読み書きだけだと辛いかもしれない)\n- WindowsのPowerShellやMac/Linuxの**ターミナルの基本操作**ができる\n\n### 想定受講者\n- Pythonを用いた画像認識・機械学習システムの実装方法について学びたい人\n- 深層学習だけでなく、画像認識・機械学習技術の背景にある理論を学びたい人\n\n### 参考図書\n- A. Geron著『scikit-learn、Keras、TensorFlowによる実践機械学習』、オライリー社\n- M. Beyeler著『OpenCVとPythonによる機械学習プログラミング』、マイナビ\n\n## License\n\n[CC BY-NC-SA 4.0](http://creativecommons.org/licenses/by-nc-sa/4.0/), 2023 (c) Tatsuya Yatagawa\n',
    'author': 'Tatsuya Yatagawa',
    'author_email': 'tatsy.mail@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.9,<3.12',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
